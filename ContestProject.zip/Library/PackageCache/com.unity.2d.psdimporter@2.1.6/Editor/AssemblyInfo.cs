using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.Psdimporter.Tests.EditorTests")]
