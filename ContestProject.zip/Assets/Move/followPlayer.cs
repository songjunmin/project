﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class followPlayer : MonoBehaviour
{
    public Transform target;
    public float bools;
    SpriteRenderer spriteRenderer;




    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }


    // Start is called before the first frame update
    void Update()
    {
        if (Input.GetButtonDown("Horizontal"))
        {
            bools = Input.GetAxisRaw("Horizontal");
            spriteRenderer.flipX = Input.GetAxisRaw("Horizontal") == -1;

        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (bools == -1)
        {
            transform.position = new Vector3(Camera.main.transform.position.x + 2, Camera.main.transform.position.y + 1, 0);
        }
    

        else
        {
            transform.position = new Vector3(Camera.main.transform.position.x - 2, Camera.main.transform.position.y + 1, 0);

        }
        
    }
}





