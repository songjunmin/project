﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraMove : MonoBehaviour
{

    public Transform target1;
    public Transform target2;
    public int targetNumber;
    // Start is called before the first frame update


    // Update is called once per frame
    void LateUpdate()
    {
        if (targetNumber == 0)
        {
            transform.position = new Vector3(target1.position.x, target1.position.y, -10f);
        }
        else
        {
            transform.position = new Vector3(target2.position.x, target2.position.y, -10f);
        }
    }


    void Update()
    {
        if (Input.GetButtonDown("e"))
        {
            targetNumber = (targetNumber + 1) % 2;

        }
    }


}
