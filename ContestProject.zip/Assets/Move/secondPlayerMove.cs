﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class secondPlayerMove : MonoBehaviour
{
    public float maxSpeed;
    public float jumpPower;
    public float doubleJump;
    public float moveAvail;
    public float sppedY;
    Rigidbody2D rigid;

    SpriteRenderer spriteRenderer;
    Transform transform;


    void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {

        //캐릭터 스와핑
        if (Input.GetButtonDown("q"))
        {
            if (moveAvail == 1)
            {
                moveAvail = 0;
            }
            else
            {
                moveAvail = 1;
            }

        }

        //스와핑 이동
        if (Input.GetButtonDown("e"))
        {
            if (!rigid.simulated)
            {
                rigid.simulated = !rigid.simulated;
                gameObject.transform.position = new Vector3(Camera.main.transform.position.x, Camera.main.transform.position.y, 0);

            }
            else
            {
                rigid.simulated = !rigid.simulated;
            }
            rigid.velocity = new Vector2(0, 0);
        }


        //jump
        if (Input.GetButtonDown("Jump"))
        {
            if (doubleJump < 2)
            {
                rigid.velocity = new Vector2(rigid.velocity.x, 0);
                rigid.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
                doubleJump += 1;
            }



        }

        //stop 구현x
        if (Input.GetButtonUp("Horizontal"))
        {
            rigid.velocity = new Vector2(rigid.velocity.normalized.x * 0.5f, rigid.velocity.y);
        }

        if (Input.GetButtonDown("Horizontal"))
            spriteRenderer.flipX = Input.GetAxisRaw("Horizontal") == -1;


    }
    // Update is called once per frame
    void FixedUpdate()
    {


        float h = Input.GetAxisRaw("Horizontal");

        rigid.AddForce(Vector2.right * h, ForceMode2D.Impulse);

        sppedY = rigid.velocity.y;

        if (Math.Abs(rigid.velocity.y) < 0.0001)
        {
            doubleJump = 0;
        }

        if (rigid.velocity.x > maxSpeed)
        {
            rigid.velocity = new Vector2(maxSpeed, rigid.velocity.y);
        }

        else if (rigid.velocity.x < maxSpeed * (-1))
        {
            rigid.velocity = new Vector2(maxSpeed * (-1), rigid.velocity.y);
        }

        //스와핑
        if (!rigid.simulated)
        {
            spriteRenderer.sortingOrder = 0;
        }
        else
        {
            spriteRenderer.sortingOrder = 7;
        }


        //Landing Plattform
        Debug.DrawRay(rigid.position, Vector3.down, new Color(0, 1, 0));

        RaycastHit2D rayHit = Physics2D.Raycast(rigid.position, Vector3.down, 1, LayerMask.GetMask("Plattform"));

        if (rayHit.collider != null)
        {
            if (rayHit.distance < 0.1f)
            {
                Debug.Log(rayHit.collider.name);

            }
        }

    }
}
